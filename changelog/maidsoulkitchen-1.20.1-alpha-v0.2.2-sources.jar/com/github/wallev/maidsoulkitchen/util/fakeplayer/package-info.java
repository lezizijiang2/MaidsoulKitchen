@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package com.github.wallev.maidsoulkitchen.util.fakeplayer;

import net.minecraft.MethodsReturnNonnullByDefault;

import javax.annotation.ParametersAreNonnullByDefault;